#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="${ROOT_DIR}/dist"
PKG_NAME="odooclaw-browser-extension.zip"

mkdir -p "${OUT_DIR}"
rm -f "${OUT_DIR}/${PKG_NAME}"

cd "${ROOT_DIR}"
zip -r "${OUT_DIR}/${PKG_NAME}" . \
  -x "*.DS_Store" \
  -x "dist/*" \
  -x "scripts/*"

printf "Created: %s\n" "${OUT_DIR}/${PKG_NAME}"
